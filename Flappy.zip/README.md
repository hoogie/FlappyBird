Til að keyra leikinn upp þarf að gera:
npm install
bower install


Bara testað í Chrome.

Þessar síður hjálpuðu okkur :)

http://thecodeplayer.com/walkthrough/pure-css3-animated-clouds-background
http://stackoverflow.com/questions/28505871/css-animation-that-moves-continually